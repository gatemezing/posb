#!/bin/bash

dt=$(date '+%H:%M:%S');
echo "$dt : start loading ..."
cat dataload00157.cypher | cypher-shell -a localhost:7687 -u neo4j -p trinity -d neo4j --format plain
dt2=$(date '+%H:%M:%S');
echo "$dt2 : Finished loading loading..." 
exit 0
